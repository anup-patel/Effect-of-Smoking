How to Run: 

python main.py